#!/bin/bash

function shinylog()
{
  echo ";;$@" >> log.txt
}
shinylog "start check"
/bin/sleep 1
shinylog "task a"
/bin/sleep 2
shinylog "task b"
/bin/sleep 1
shinylog "check passed"
/bin/sleep 2
shinylog "finished"
