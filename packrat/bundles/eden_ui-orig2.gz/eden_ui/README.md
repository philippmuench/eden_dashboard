# EDEN (user interface)

see https://github.com/philippmuench/eden for the EDEN repository
